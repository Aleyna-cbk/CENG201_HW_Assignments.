public class Return_request {
    int user_id;
    int book_id;
    long returnTime;
    Return_request next;
    public Return_request(int user__id, int book__id, long return_Time, Return_request next) {
        user_id = user__id;
        book_id = book__id;
        returnTime = return_Time;
        next = null;
    }
    public String toString() {
        return "ReturnRequest{" +
                "userId: " + user_id +
                "bookId: " + book_id +
                "returnTime: " + returnTime +
                "}";
    }

}
