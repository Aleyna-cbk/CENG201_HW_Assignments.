public class Borrow_queue {
    private Borrow_request front;
    private Borrow_request rear;
    private int size;
    public Borrow_queue() {
        front = null;
        rear = null;
        size = 0;
    }
    public void enqueue(Borrow_request request) {
        if (rear == null) {
            front = request;
            rear = request;
        }
        else {
            rear.next = request;
            rear = request;
        }
        size++;
        System.out.println("New borrowing request added to the queue" + request);
    }
    public Borrow_request dequeue(){
        if (front == null){
            System.out.println("Queue is empty");
            return null;
        }
        Borrow_request dequeuerequest = front;
        front = front.next;
        if (front == null){
            rear = null;
        }
        size--;
        System.out.println("Processing and removing borrowing request" + dequeuerequest);
        return dequeuerequest;
    }
    public int size(){
        return size;
    }
    public void printQueue(){
        if (front == null){
            System.out.println("Queue is empty");
            return;
        }
        Borrow_request current = front;
        System.out.println("--Current borrowing queue--");
        while (current != null){
            System.out.println(current);
            current = current.next;
        }
        System.out.println("----");
    }
}