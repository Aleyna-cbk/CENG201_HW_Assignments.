import java.awt.print.Book;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        System.out.println("Test_for_Book_list");
        Book_list book_list = new Book_list();
        book_list.add(new Book(50, "In Order To Live", "Yeonmi Park"));
        book_list.add(new Book(51, "Sari Sicak", "Yasar Kemal"));
        book_list.add(new Book(52, "Bir Genc Kizin Uyusturucu Gunlugu", "Anonymous"));
        book_list.add(new Book(53, "1984", "George Orwell"));
        book_list.print_books();

        System.out.println("\n Deleting book with ID 50");
        book_list.delete_book(50);
        book_list.print_books();
        System.out.println("\n Searching for book with ID 51");
        Book found_book = book_list.search_book(51);
        if (found_book != null) {
            System.out.println("Found: " + found_book);
        }
        else {
            System.out.println("No book found");
        }
        System.out.println("\nFinal list: ");
        book_list.print_books();
    }
}

public class main {
    public static void main(String[] args) {
        System.out.println("Test_for_Book_request");
        Book_list book_list = new Book_list();
        book_list.add (new Book (50, "In Order To Live", "Yeonmi Park"));
        book_list.add (new Book (51, "Sari Sicak", "Yasar Kemal"));
        book_list.add (new Book (52, "Bir Genc Kizin Uyusturucu Gunlugu", "Anonymous"));
        book_list.add (new Book (53, "1984", "George Orwell"));
        book_list.print_books();

        System.out.println("\n Deleting book with ID 51...");
        book_list.delete_book(52);
        book_list.print_books();

        System.out.println("\n Searching for book with ID 51...");
        Book found_book = book_list.search_book(51);
        if (found_book != null) {
            System.out.println("Found: " + found_book);
        }
        else {
            System.out.println("No book found");
        }
        System.out.println("\nFinal list: ");
        book_list.print_books();

        System.out.println("\n--- Mission2: Borrowing Queue Test Scenario");
        Borrow_queue borrowQueue = new Borrow_queue()ueue();
        System.out.println("Adding 10 requests to the queue");
        borrowQueue.enqueue(new Borrow_request(1,1));
        borrowQueue.enqueue(new Borrow_request(2,2));
        borrowQueue.enqueue(new Borrow_request(3,3));
        borrowQueue.enqueue(new Borrow_request(4,4));
        borrowQueue.enqueue(new Borrow_request(5,5));
        borrowQueue.enqueue(new Borrow_request(6,6));
        borrowQueue.enqueue(new Borrow_request(7,7));
        borrowQueue.enqueue(new Borrow_request(8,8));
        borrowQueue.enqueue(new Borrow_request(9,9));
        borrowQueue.enqueue(new Borrow_request(10,10));
        System.out.println("\nFirst_Queue: ");
        borrowQueue.printQueue();

        System.out.println("\nProcessing and deleting requests from the queue: ");
        borrowQueue.dequeue();
        borrowQueue.dequeue();
        borrowQueue.dequeue();

        System.out.println("\nRest of the queue: ");
        borrowQueue.printQueue();
        System.out.println("\n------");


        System.out.println("\nMission3: Return Stack Test Scenario ");
        Return_stack returnStack = new Return_stack();
        System.out.println("Adding 5 return requests to the stack");
        returnStack.push(new Return_request(1,1));
        returnStack.push(new Return_request(2,2));
        returnStack.push(new Return_request(3,3));
        returnStack.push(new Return_request(4,4));
        returnStack.push(new Return_request(5,5));
        System.out.println("\nInitial Stack State: ");
        returnStack.printStack();
        System.out.println("\nProcessing and deleting 2 requests from the stack: ");
        returnStack.pop();
        returnStack.pop();

        System.out.println("\nTop request of the stack (peek): " + returnStack.peek());
        System.out.println("\nRemaining stack state: ");
        returnStack.printStack();
        System.out.println("\n------");

        System.out.println("\nMission4: LibrarySystem Test Scenario ");
        System.out.println("\nCreating a LibrarySystem object...");

        Library_system library = new Library_system();
        System.out.println("\nAdding initial books to the library...");
        library.book_list.add(new Book(1, "The Lord of the Rings", "J.R.R. Tolkien"));
        library.book_list.add(new Book(2, "The Hobbit", "J.R.R. Tolkien"));
        library.book_list.add(new Book(3, "1984", "George Orwell"));
        library.book_list.add(new Book(4, "To Kill a Mockingbird", "Harper Lee"));

        System.out.println("\nAdding mixed borrowing requests (priority and normal)...");
        library.borrow_queue(201, 1); // Priority request
        library.borrow_queue(202, 2); // Normal request
        library.borrow_queue(203, 3); // Priority request
        library.borrow_queue(204, 4); // Normal request
        library.borrow_queue(205, 1); // Priority request

        System.out.println("\n--- Current Library System Status Before Processing ---");
        library.printSystemStatus();

        System.out.println("\nProcessing borrowing requests...");
        library.processBorrowingRequest();

        System.out.println("\nAdding a few return requests...");
        library.return_book(201, 1);
        library.return_book(203, 3);

        System.out.println("\nProcessing return requests (popping from stack)...");
        library.return_stack.pop();
        library.return_stack.pop();

        System.out.println("\n--- Final Library System Status ---");
        library.printSystemStatus();

        System.out.println("\n--- Task 4 Test Scenario Completed ---");

    }
}
}

