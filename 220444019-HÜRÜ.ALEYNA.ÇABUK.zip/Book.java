public class Book {
    int id;
    String title;
    String author;

    Book next;
    public Book(int book_id, String book_title, String book_author) {
        id = book_id;
        title = book_title;
        author = book_author;
        next = null;
    }
    public String toString() {
        return "Book{" +
                "Book ID: " + id +
                "Book Title: " + title + "/" +
                "Book Author: " + author + "/" +
                "}";
    }
}