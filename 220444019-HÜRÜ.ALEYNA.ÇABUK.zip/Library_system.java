public class Library_system {
    Book_list book_list;
    Borrow_queue borrow_queue;
    Return_stack return_stack;

    public Library_system() {
        book_list = new Book_list();
        borrow_queue = new Borrow_queue();
        return_stack = new Return_stack();
    }
    public void processBorrowingRequest(){
        System.out.println("Processing Borrowing Request Based On Priority...");
        Borrow_queue temporary_queue = new Borrow_queue();
        Borrow_request current;

        while ((current = borrow_queue.dequeue()) != null){
            if (current.user_id % 2 != 0){
                System.out.println("Processing Priority Request: " + current);
            }
            else{
                temporary_queue.enqueue(current);
            }
        }
        while ((current = temporary_queue.dequeue()) != null){
            System.out.println("Processing Normal Request: " + current);
        }
        System.out.println("All borrowing request have been processed.");
    }
    public void Borrow_book(int user_id, int book_id){
        Borrow_request new_request = new Borrow_request(user_id, book_id);
        Borrow_queue borrowQueue = borrow_queue;
        borrowQueue.enqueue(new_request);
    }
    public void return_book(int user_id, int book_id){
        Return_request newRequest = new Return_request(user_id, book_id);
        return_stack.push(newRequest);
    }
    public void printSystemStatus(){
        System.out.println("\n Current Library System Status");
        System.out.println("Books in Library");
        book_list.print_books();
        System.out.println("\n Borrowig Queue");
        borrow_queue.printQueue();
        System.out.println("\n Returning Stack");
        return_stack.printStack();
        System.out.println(" ------\n");
    }
}
