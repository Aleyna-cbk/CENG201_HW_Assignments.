public class Borrow_request {
    int user_id;
    int book_id;
    long time;
    Borrow_request next;

    public Borrow_request(int user__id, int book__id, long time_, Borrow_request next) {
        user_id = user__id;
        book_id = book__id;
        time = time_;
        next = null;
    }
    public String toString() {
        return "Borrow_request{" +
                "user__id = " + user_id +
                "book__id = " + book_id +
                "time = " + time +
                "}";
    }
}
