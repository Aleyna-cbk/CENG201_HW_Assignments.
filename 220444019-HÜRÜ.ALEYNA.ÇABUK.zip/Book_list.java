public class Book_list {
    private Book head;

    public Book_list() {
        head = null;
    }

    public void add(Book book) {
        if (head == null) {
            head = book;
        } else {
            Book current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = book;
        }
    }

    public void delete_book(int id) {
        if (head == null) {
            System.out.println("Book list is empty. Cannot delete book.");
            return;
        }
        if (head.id == id) {
            head = head.next;
            System.out.println(id + "book is deleted successfully.");
            return;
        }
        Book current = head;
        while (current.next != null) {
            current = current.next;
        }
        if (current.next != null) {
            current.next = current.next.next;
            System.out.println(id + "book is deleted successfully.");
        } else {
            System.out.println(id + "book could not be found.");
        }
    }

    public Book search_book(int id) {
        Book current = head;
        while (current != null) {
            if (current.id == id) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

    public void print_books() {
        if (head == null) {
            System.out.println("Book list is empty. Cannot print books.");
            return;
        }
        Book current = head;
        System.out.println(head.id + "books are :");
        while (current != null) {
            System.out.println(current);
            current = current.next;
        }
        System.out.println("-----");
    }
}
