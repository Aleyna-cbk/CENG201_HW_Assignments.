public class Return_stack {
    private Return_stack top;
    public Return_stack() {
        top = null;
    }
    public void push(Return_request request) {
        request.next = top;
        top = request;
        System.out.println ("New return request added to the Stack.");
    }
    public Return_request pop() {
        if (top == null) {
            System.out.println("Stack is empty.");
            return null;
        }
        Return_request poppedRequest = top;
        top = top.next;
        System.out.println ("Processing and removing return request: ");
        return poppedRequest;
    }
    public Return_request peek() {
        if (top == null) {
            return null;
        }
        return top;
    }
    public boolean isEmpty() {
        return top == null;
    }
    public void printStack() {
        if (top == null) {
            System.out.println("Stack is empty.");
            return;
        }
        Return_request current = top;
        System.out.println ("Current stack");
        while (current != null) {
            System.out.println (current);
            current = current.next;
        }
        System.out.println ("-------");
    }
}
