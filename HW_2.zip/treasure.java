public class treasure {
    int id;
    String name;
    int point;
    treasure next;
    public treasure(int treasure_id, String treasure_name, int treasure_point) {
        id = treasure_id;
        name = treasure_name;
        point = treasure_point;
        next = null;
    }
    public String to_string() {
        return "Treasure {" +
                "ID= " + id +
                ", Name: " + name +
                ", Points= " + point +
                "}";
    }
}