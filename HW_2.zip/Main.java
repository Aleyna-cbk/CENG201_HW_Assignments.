public class Main {
    public static void main(String[] args) {
        System.out.println("Task 1 : Treasure Inventory Test Scenario");
        treasure_inventory inventory = new treasure_inventory();
        System.out.println("Adding 3 treasures to the inventory");
        inventory.add_treasure(new treasure(1, "Golden Amulet", 100));
        inventory.add_treasure(new treasure(52, "Silver", 50));
        inventory.add_treasure(new treasure(14, "Iron", 120));
        System.out.println("\n Initial state of the inventory");
        inventory.print_inventory();

        System.out.println("\n Removing the treasure with ID 52...");
        inventory.remove_treasure(52);

        System.out.println("\n Searching for the treasure with ID 1...");
        inventory.find_treasure(1);

        System.out.println("\n Final state of the inventory");
        inventory.print_inventory();

        System.out.println("\n Task 1 scenario is completed");


        System.out.println("\n Task 2: Player Scoreboard Test Scenario");
        score_board scoreboard = new score_board();
        System.out.println("\n Adding 10 players to the scoreboard ");
        scoreboard.add_player(new Player(1, "Aleyna", 99));
        scoreboard.add_player(new Player(2, "Betul", 90));
        scoreboard.add_player(new Player(3, "Ipek", 85));
        scoreboard.add_player(new Player(4, "Gorkem", 70));
        scoreboard.add_player(new Player(5, "Nida", 81));
        scoreboard.add_player(new Player(6, "Sude", 87));
        scoreboard.add_player(new Player(7, "Lale", 100));
        scoreboard.add_player(new Player(8, "Duygu", 83));
        scoreboard.add_player(new Player(9, "Hulya", 76));
        scoreboard.add_player(new Player(10, "Ayse", 98));

        System.out.println("\n Scoreboard before sorting: ");
        scoreboard.print_scoreboard();

        scoreboard.sort_players();
        System.out.println("\n Scoreboard after sorting: ");
        scoreboard.print_scoreboard();

        System.out.println("\n Task2 Test Scenario is completed");


        System.out.println("\n Task 3:  Hunt Route Planner Test Scenario");
        route_planner route_planner = new route_planner();

        System.out.println("\n Adding 8 routes to the route planner. ");
        route_planner.add_route(new hunt_route(1,2.5,100));
        route_planner.add_route(new hunt_route(2,2.9,50));
        route_planner.add_route(new hunt_route(3,0.9,95));
        route_planner.add_route(new hunt_route(4,1.5,100));
        route_planner.add_route(new hunt_route(5,3.8,120));
        route_planner.add_route(new hunt_route(6,1.2,75));
        route_planner.add_route(new hunt_route(7,5.1,200));
        route_planner.add_route(new hunt_route(8,4.3,80));

        System.out.println("\n Roat List before sorting: ");
        route_planner.print_routes();

        route_planner.sort_routes();

        System.out.println("\n Roat List after sorting: ");
        route_planner.print_routes();

        System.out.println("\n Task3 Test Scenario is completed");
    }

}
