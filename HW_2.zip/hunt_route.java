public class hunt_route {
    int treasure_id;
    double distance;
    int points;

    public hunt_route (int treasureID, double Distance, int Points) {
        treasure_id = treasureID;
        distance = Distance;
        points = Points;
    }

    public String toString () {
        return "HuntRoute{" +
                "treasureID: " + treasure_id +
                "distance: " + distance +
                "points: " + points +
                "}";
    }
}
