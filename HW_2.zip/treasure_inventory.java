public class treasure_inventory {
    private static final int table_size = 10;
    private treasure [] table;

    public treasure_inventory() {
        table = new treasure[table_size];
    }
    private int hash (int key) {
        return key % table_size;
    }
    public void add_treasure (treasure treasure) {
        int index = hash(treasure.id);

        if (table[index] == null) {
            table[index] = treasure;
        }
        else {
            treasure current = table[index];
            while (current.next != null) {
                current = current.next;
            }
            current.next = treasure;
        }
        System.out.println(treasure.id + " New Treasure added: ");
    }
    public void remove_treasure (int id){
        int index = hash(id);
        treasure current = table[index];
        treasure previous = null;

        while (current != null && current.id != id) {
            previous = current;
            current = current.next;
        }
        if (current == null) {
            System.out.println("Treasure with id " + id + " not found");
        }
        else {
            if (previous == null) {
                table[index] = current.next;
            }
            else {
                previous.next = current.next;
            }
            System.out.println(id + " Removed Treasure with id " + id);
        }
    }
    public treasure find_treasure (int id) {
        int index = hash(id);
        treasure current = table[index];

        while (current != null && current.id != id) {
            current = current.next;
        }
        if (current == null) {
            System.out.println("Treasure with id " + id + " not found");
            return null;
        }
        else{
            System.out.println(id + " Found Treasure with id: " + id);
            return current;
        }
    }
    public void print_inventory() {
        System.out.println("Current inventory");
        for (int i = 0; i < table_size; i++) {
            treasure current = table[i];
            if (current != null) {
                System.out.println("Index: " + i + ":");
                while (current != null) {
                    System.out.print(current + "-->");
                    current = current.next;
                }
                System.out.println("null");
            }
        }
        System.out.println("-------------");
    }
}