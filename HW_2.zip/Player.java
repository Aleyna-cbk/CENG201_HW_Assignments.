public class Player {
    int player_id;
    String player_name;
    int player_score;

    public Player(int id, String name, int score) {
        player_id = id;
        player_name = name;
        player_score = score;
    }
    public String to_sring() {
        return "Player{" +
                "player_id" + player_name +
                ", name = " + player_name +
                ", score = " + player_score +
                "}";
    }
}