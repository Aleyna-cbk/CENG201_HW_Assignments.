public class score_board {
    private Player[] players;
    private int player_count;
    private static final int max_players = 100;

    public score_board() {
        players = new Player[max_players];
        player_count = 0;
    }
    public void add_player(Player player) {
        if (player_count < max_players) {
            players[player_count] = player;
            player_count++;
        }
        else {
            System.out.println("Scoreboard is full, cannot add player");
        }
    }

    public void sort_players() {
        System.out.println("Sorting scoreboard using Qucicksort...");
        quickSort(0,player_count - 1);
    }
    private void quickSort(int low, int high) {
        if (low < high) {
            int partition_index = partition(low , high);
            quickSort(low , partition_index - 1);
            quickSort(partition_index + 1, high);
        }
    }
    private int partition(int low, int high) {
        int pivot = players[high].player_score;
        int i = (low - 1);

        for (int j = low; j < high; j++) {
            if (players[j].player_score > pivot) {
                i ++;
                Player temp = players[i];
                players[i] = players[j];
                players[j] = temp;
            }
        }
        Player temp = players[i + 1];
        players[i + 1] = players[high];
        players[high] = temp;
        return i + 1;
    }
    public void print_scoreboard() {
        System.out.println("Current Scoreboard: " + player_count);
        for (int i = 0; i < player_count; i++) {
            System.out.println(players[i]);
        }
        System.out.println("---");
    }
}
