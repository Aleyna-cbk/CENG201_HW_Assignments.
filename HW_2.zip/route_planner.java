public class route_planner {
    private hunt_route[] routes;
    private int route_count;
    private static final int max_routes = 10;

    public route_planner() {
        routes = new hunt_route[max_routes];
        route_count = 0;
    }
    public void add_route(hunt_route route) {
        if (route_count < max_routes) {
            routes[route_count] = route;
            route_count++;
        }
        else {
            System.out.println("Route planner is full now.");
        }
    }
    public void sort_routes() {
        System.out.println("Sorted routes using MergeSort");
        merge_sort(0,route_count - 1);
    }
    private void merge_sort(int low, int high) {
        if (low < high) {
            int mid = (low + high) / 2;
            merge_sort(low, mid);
            merge_sort(mid + 1, high);
            merge(low, mid, high);
        }
    }
    private void merge(int low, int mid, int high) {
        hunt_route [] left_array = new hunt_route[high - low + 1];
        hunt_route [] right_array = new hunt_route[high - mid];

        for (int i = 0; i < left_array.length; i++) {
            left_array[i] = routes[low + i];
        }
        for (int j = 0; j < right_array.length; j++) {
            right_array[j] = routes[mid + 1 + j];
        }
        int i = 0, j = 0;
        int k = low;

        while (i < left_array.length && j < right_array.length) {
            if (left_array[i].distance <= right_array[j].distance){
                routes[k] = left_array[i];
                i++;
            }
            else{
                routes[k] = right_array[j];
                j++;
            }
            k++;
        }
        while (i < left_array.length) {
            routes[k] = left_array[i];
            i++;
            k++;
        }
        while (j < right_array.length) {
            routes[k] = right_array[j];
            j++;
            k++;
        }
    }
    public void print_routes() {
        System.out.println("Current routes");
         for (int i = 0; i < route_count; i++) {
             System.out.println(routes[i]);
         }
         System.out.println("---");
    }
}
